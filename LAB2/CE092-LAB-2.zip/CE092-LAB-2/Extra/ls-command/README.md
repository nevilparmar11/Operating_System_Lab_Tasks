# ls-command
implementation of the ls command in C
