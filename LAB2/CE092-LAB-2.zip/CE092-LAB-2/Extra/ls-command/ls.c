#include "ls.h"
#include <regex.h>
#include <errno.h>
#include <time.h>

char *get_file_name(const char *name);

//Checks that the names of a file doesnt start with '.'
int filter(const struct dirent *entry)
{
        //if first char is a '.'
        if (entry->d_name[0] == '.')
        {
                return a_flag ? 1 : 0;
        }
        return 1;
}

//Gets scandir to sort the contents by time
int t_compare(const struct dirent **entry1, const struct dirent **entry2)
{
        struct stat one, two;
        int compare = 0;

        //get whole path relative to current directory
        char *name1 = get_file_name((*entry1)->d_name);
        char *name2 = get_file_name((*entry2)->d_name);

        //if can stat these files, compare their sizes
        if ((lstat(name1, &one) == 0) && (lstat(name2, &two) == 0))
        {
                //if r flag active as well, sort ascending based on file size
                //else descending
                compare = !r_flag ? two.st_mtime - one.st_mtime
                                  : one.st_mtime - two.st_mtime;
        }
        free(name1);
        free(name2);
        return compare;
}

//Gets scandir to sort the contents by size in bytes
int S_compare(const struct dirent **entry1, const struct dirent **entry2)
{
        struct stat one, two;
        int compare = 0;
        //get whole path relative to current directory
        char *name1 = get_file_name((*entry1)->d_name);
        char *name2 = get_file_name((*entry2)->d_name);

        //if can stat these files, compare their sizes
        if ((lstat(name1, &one) == 0) && (lstat(name2, &two) == 0))
        {
                //if r flag active as well, sort ascending based on file size
                //else descending
                compare = !r_flag ? two.st_size - one.st_size
                                  : one.st_size - two.st_size;
        }
        free(name1);
        free(name2);
        return compare;
}

//The comparison function used with scandir
int compare(const struct dirent **entry1, const struct dirent **entry2)
{
        //sort by time
        if (t_flag)
        {
                return t_compare(entry1, entry2);
        }
        //sort by size in bytes
        if (S_flag)
        {
                return S_compare(entry1, entry2);
        }

        //otherwise sort alphabetically (ascending)
        if (!r_flag)
                return strcasecmp((*entry1)->d_name, (*entry2)->d_name);

        //descending
        return strcasecmp((*entry2)->d_name, (*entry1)->d_name);
}

//Sets the flags for this particular arg
void set_flags(char *arg)
{
        //allows for args like '-Sn' instead of just '-S -n'
        for (unsigned int j = 1; j < strlen(arg); j++)
        {
                switch (arg[j])
                {
                case 'l':
                        l_flag = 1;
                        break;
                case 'S':
                        S_flag = 1;
                        break;
                case 'R':
                        R_flag = 1;
                        break;
                case 't':
                        t_flag = 1;
                        break;
                case 'i':
                        i_flag = 1;
                        break;
                case 'n':
                        n_flag = 1;
                        break;
                case 'r':
                        r_flag = 1;
                        break;
                case 'a':
                        a_flag = 1;
                        break;

                //unrecognised flag
                default:
                {
                        errno = EINVAL;
                        perror("Invalid flag");
                        exit(0);
                }
                }
        }
}

//Looks at the different args passed into the program
int check_args(int argc, char **argv)
{
        paths = malloc(2);
        paths[0] = ".";
        int num_paths = 0;
        int size = 0;
        //for each command line arg
        for (int i = 1; i < argc; i++)
        {
                char *arg = argv[i];

                //if flag
                if (arg[0] == '-')
                {
                        set_flags(arg);
                }
                else
                {
                        size += strlen(arg) + 1;
                        paths = realloc(paths, size);
                        if (path != NULL)
                                paths[num_paths++] = arg;
                }
        }
        return num_paths == 0 ? 1 : num_paths;
}

//Free all entries within the directory global variable
void free_directory(struct dirent **directory, int num_files)
{
        for (int i = 0; i < num_files; i++)
        {
                free(directory[i]);
        }
        free(directory);
}
